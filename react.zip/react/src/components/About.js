import React from 'react';


const About = () => {
    return (
        <div>
        <p>
        aboot
        </p>
        </div>
    );
}

export default About;