import React from 'react';


const Loader = () => {
    return (
        <div class="loader"></div>
    );
}

export default Loader;